package ru.netology.kubrakova.exception;

public class OperationRuntimeException extends RuntimeException {
}
